<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('admin.dashboard');
});

//tampil data user
Route::get('/data-user', function () {
    return view('admin.data.data-user');
});

//tambah data user
Route::get('/add-user', function () {
    return view('admin.management-user.add-user');
});

//detail data user
Route::get('/detail-user', function () {
    return view('admin.management-user.detail-user');
});

//detail data user
Route::get('/edit-user', function () {
    return view('admin.management-user.edit-user');
});






/** SUPERADMIN */
Route::middleware('auth:superadmin')->prefix('sadmin')->group(function () {
    /** Dashboard */
    Route::get('/', [HomeController::class, 'dashboardSuperAdmin']);
});

/** ADMIN */
Route::middleware('auth:admin')->prefix('admin')->group(function () {
    /** Dashboard */
    Route::get('/', [HomeController::class, 'dashboardAdmin']);

    /** Data Users */
    Route::resource('users', UserController::class);
});

/** Auth */
Route::get('/login', [AuthController::class, 'index'])
    ->name('login');
Route::post('/postlogin', [AuthController::class, 'login'])
    ->name('postlogin');
Route::post('/', [AuthController::class, 'logout'])
    ->name('logout');

/** API */
